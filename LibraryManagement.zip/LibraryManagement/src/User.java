import java.sql.*;

public class User {
    public void searchBook(String keyword) {
        String query = "SELECT * FROM books WHERE title LIKE ?";
        try (Connection conn = DBConnection.connect();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            boolean found = false;
            while (rs.next()) {
                found = true;
                System.out.printf("%d | %s | %s | %s\n",
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getInt("available") == 1 ? "Available" : "Not Available");
            }
            if (!found) {
                System.out.println("No book found.");
            }
        } catch (SQLException e) {
            System.out.println("Search error: " + e);
        }
    }
}
