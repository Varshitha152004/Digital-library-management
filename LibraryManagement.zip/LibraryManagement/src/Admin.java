import java.sql.*;

public class Admin {
    public void addBook(String title, String author) {
        String query = "INSERT INTO books (title, author, available) VALUES (?, ?, 1)";
        try (Connection conn = DBConnection.connect();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, title);
            ps.setString(2, author);
            ps.executeUpdate();
            System.out.println("Book added successfully!");
        } catch (SQLException e) {
            System.out.println("Add book error: " + e);
        }
    }

    public void viewBooks() {
        String query = "SELECT * FROM books";
        try (Connection conn = DBConnection.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                System.out.printf("%d | %s | %s | %s\n",
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getInt("available") == 1 ? "Available" : "Not Available");
            }
        } catch (SQLException e) {
            System.out.println("View books error: " + e);
        }
    }

    public void deleteBook(int id) {
        String query = "DELETE FROM books WHERE id = ?";
        try (Connection conn = DBConnection.connect();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            System.out.println(rows > 0 ? "Book deleted!" : "No book found with that ID.");
        } catch (SQLException e) {
            System.out.println("Delete book error: " + e);
        }
    }
}
