import java.sql.*;

public class DBConnection {
    public static Connection connect() {
        try {
            Class.forName("org.sqlite.JDBC");
            return DriverManager.getConnection("jdbc:sqlite:library.db");
        } catch (Exception e) {
            System.out.println("DB connection error: " + e);
            return null;
        }
    }

    public static void initialize() {
        String createTable = "CREATE TABLE IF NOT EXISTS books (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT NOT NULL," +
                "author TEXT NOT NULL," +
                "available INTEGER DEFAULT 1" +
                ");";
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(createTable);
        } catch (SQLException e) {
            System.out.println("Table creation error: " + e);
        }
    }
}
