import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        DBConnection.initialize(); // Ensure DB and table exist
        Scanner sc = new Scanner(System.in);
        Admin admin = new Admin();
        User user = new User();

        System.out.println("===== Library Management System =====");
        System.out.println("Choose role: 1. Admin  2. User");
        int role = sc.nextInt();
        sc.nextLine();

        if (role == 1) {
            System.out.println("1. Add Book");
            System.out.println("2. View Books");
            System.out.println("3. Delete Book");
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 1) {
                System.out.print("Enter title: ");
                String title = sc.nextLine();
                System.out.print("Enter author: ");
                String author = sc.nextLine();
                admin.addBook(title, author);
            } else if (choice == 2) {
                admin.viewBooks();
            } else if (choice == 3) {
                System.out.print("Enter book ID to delete: ");
                int id = sc.nextInt();
                admin.deleteBook(id);
            }
        } else if (role == 2) {
            System.out.print("Enter book title to search: ");
            String keyword = sc.nextLine();
            user.searchBook(keyword);
        }
        sc.close();
    }
}
